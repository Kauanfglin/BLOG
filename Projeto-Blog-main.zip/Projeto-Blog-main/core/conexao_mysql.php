<?php

// Função para estabelecer uma conexão com o banco de dados MySQL
function conecta() : mysqli
{
    // Definindo as variáveis para conexão
    $servidor = 'localhost'; // O servidor onde o banco de dados está hospedado
    $banco = 'blog'; // Nome do banco de dados ao qual queremos nos conectar
    $port = 3307; // Porta em que o MySQL está escutando (padrão é 3306, mas aqui é 3307)
    $usuario = 'root'; // Nome de usuário para autenticação no banco de dados
    $senha = ''; // Senha para o usuário (neste caso, nenhuma senha é definida)

    // Tentativa de conectar ao banco de dados usando mysqli_connect
    $conexao = mysqli_connect($servidor, $usuario, $senha, $banco, $port);

    // Verifica se a conexão foi bem-sucedida
    if (!$conexao) {
        // Se a conexão falhar, exibe mensagens de erro
        echo 'Erro: Não foi possível conectar ao MySql.' . PHP_EOL; // Mensagem genérica de erro
        echo 'Debugging errno: ' . mysqli_connect_errno() . PHP_EOL; // Código de erro da conexão
        echo 'Debugging error: ' . mysqli_connect_error() . PHP_EOL; // Mensagem de erro mais detalhada
        return null; // Retorna null se a conexão falhar
    }
    
    // Retorna o objeto de conexão se a conexão for bem-sucedida
    return $conexao;
}

// Função para fechar a conexão com o banco de dados
function desconecta($conexao)
{
    // Fecha a conexão usando mysqli_close
    mysqli_close($conexao);
}

?>
