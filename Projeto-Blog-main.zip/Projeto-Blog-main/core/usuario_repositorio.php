<?php
session_start(); // Inicia ou retoma uma sessão existente.
require_once '../includes/funcoes.php'; // Inclui funções auxiliares.
require_once 'conexao_mysql.php'; // Inclui o arquivo de conexão ao MySQL.
require_once 'sql.php'; // Inclui consultas SQL.
require_once 'mysql.php'; // Inclui funções específicas para operações no MySQL.

$salt = '%exemplosaltifsp'; // Define um salt para a criptografia da senha.

// Limpa os dados recebidos via POST.
foreach ($_POST as $indice => $dado) {
    $$indice = limparDados($dado); // Limpa os dados e os atribui a variáveis dinâmicas.
}

// Limpa os dados recebidos via GET.
foreach ($_GET as $indice => $dado) {
    $$indice = limparDados($dado); // Limpa os dados e os atribui a variáveis dinâmicas.
}

// Switch para determinar a ação a ser tomada com base na variável $acao.
switch ($acao) {
    case 'insert': // Caso para inserir um novo usuário.
        $dados = [
            'nome'  => $nome, // Nome do usuário.
            'email' => $email, // Email do usuário.
            'senha' => crypt($senha, $salt) // Criptografa a senha com um salt.
        ];

        insere('usuario', $dados); // Chama a função insere para adicionar o usuário.
        break;

    case 'update': // Caso para atualizar informações do usuário.
        $id = (int)$id; // Converte o ID para inteiro.
        $dados = [
            'nome'  => $nome, // Nome atualizado.
            'email' => $email // Email atualizado.
        ];

        $criterio = [
            ['id', '=', $id] // Critério para localizar o usuário a ser atualizado.
        ];

        atualiza('usuario', $dados, $criterio); // Chama a função atualiza para modificar os dados.
        break;

    case 'login': // Caso para realizar login.
        $criterio = [
            ['email', '=', $email], // Busca pelo email.
            ['AND', 'ativo', '=', 1] // Garante que o usuário está ativo.
        ];

        $retorno = buscar('usuario', ['id', 'nome', 'email', 'senha', 'adm'], $criterio); // Busca os dados do usuário.

        if (count($retorno) > 0) { // Se o usuário foi encontrado.
            if (crypt($senha, $salt) == $retorno[0]['senha']) { // Verifica se a senha está correta.
                $_SESSION['login']['usuario'] = $retorno[0]; // Armazena os dados do usuário na sessão.

                if (!empty($_SESSION['url_retorno'])) { // Se há uma URL para retornar.
                    header('Location: ' . $_SESSION['url_retorno']); // Redireciona para a URL.
                    $_SESSION['url_retorno'] = ''; // Limpa a URL de retorno.
                    exit; // Interrompe a execução do script.
                }
            }
        }
        break;

    case 'logout': // Caso para realizar logout.
        session_destroy(); // Destrói a sessão atual.
        break;

    case 'status': // Caso para alterar o status (ativo/inativo) do usuário.
        $id = (int)$id; // Converte o ID para inteiro.
        $valor = (int)$valor; // Converte o valor para inteiro.
        
        $dados = [
            'ativo' => $valor // Define o novo status do usuário.
        ];

        $criterio = [
            ['id', '=', $id] // Critério para localizar o usuário a ser atualizado.
        ];

        atualiza('usuario', $dados, $criterio); // Chama a função atualiza.
        header('Location: ../usuarios.php'); // Redireciona para a página de usuários.
        exit; // Interrompe a execução do script.
        break;

    case 'adm': // Caso para alterar o status de administrador do usuário.
        $id = (int)$id; // Converte o ID para inteiro.
        $valor = (int)$valor; // Converte o valor para inteiro.
        
        $dados = [
            'adm' => $valor // Define o novo status de administrador do usuário.
        ];

        $criterio = [
            ['id', '=', $id] // Critério para localizar o usuário a ser atualizado.
        ];

        atualiza('usuario', $dados, $criterio); // Chama a função atualiza.
        header('Location: ../usuarios.php'); // Redireciona para a página de usuários.
        exit; // Interrompe a execução do script.
        break;
}

// Redireciona para a página inicial após a operação.
header('Location: ../index.php');
?>
