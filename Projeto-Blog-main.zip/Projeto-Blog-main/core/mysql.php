<?php

// Função para inserir dados em uma tabela
function insere(string $entidade, array $dados) : bool
{
    $retorno = false; // Inicializa a variável de retorno como falso

    // Prepara os dados para a inserção
    foreach ($dados as $campo => $dado) {
        $coringa[$campo] = '?'; // Usa '?' como coringa para a query
        $tipo[] = gettype($dado)[0]; // Obtém o tipo do dado
        $$campo = $dado; // Cria uma variável variável com o nome do campo
    }

    // Monta a instrução SQL de inserção
    $instrucao = insert($entidade, $coringa);

    // Conecta ao banco de dados
    $conexao = conecta();

    // Prepara a instrução SQL
    $stmt = mysqli_prepare($conexao, $instrucao);

    // Vincula os parâmetros da instrução
    eval('mysqli_stmt_bind_param($stmt, \'' . implode('', $tipo) . '\',$'
    . implode(', $', array_keys($dados)) . '); ');

    // Executa a instrução
    mysqli_stmt_execute($stmt);
    
    // Verifica se a execução afetou alguma linha
    $retorno = (boolean) mysqli_stmt_affected_rows($stmt);

    // Armazena erros, se houver
    $_SESSION['erros'] = mysqli_stmt_error_list($stmt);

    // Fecha a instrução
    mysqli_stmt_close($stmt);

    // Desconecta do banco de dados
    desconecta($conexao);

    return $retorno; // Retorna o resultado da operação
}

// Função para atualizar dados em uma tabela
function atualiza(string $entidade, array $dados, array $criterio = []) : bool
{
    $retorno = false; // Inicializa a variável de retorno como falso

    // Prepara os dados para a atualização
    foreach ($dados as $campo => $dado) {
        $coringa_dados[$campo] = '?'; // Usa '?' como coringa
        $tipo[] = gettype($dado)[0]; // Obtém o tipo do dado
        $$campo = $dado; // Cria uma variável variável
    }

    // Prepara os critérios para a atualização
    foreach ($criterio as $expressao) {
        $dado = $expressao[count($expressao) - 1];

        $tipo[] = gettype($dado)[0]; // Obtém o tipo do dado
        $expressao[count($expressao) - 1] = '?'; // Substitui o valor pelo coringa
        $coringa_criterio[] = $expressao; // Armazena a expressão de critério

        $nome_campo = (count($expressao) < 4) ? $expressao[0] : $expressao[1];

        if (isset($nome_campo)) {
            $nome_campo = $nome_campo . '_' . rand(); // Cria um nome de campo único
        }

        $campos_criterio[] = $nome_campo; // Armazena o nome do campo
        $$nome_campo = $dado; // Cria uma variável variável para o critério
    }

    // Monta a instrução SQL de atualização
    $instrucao = update($entidade, $coringa_dados, $coringa_criterio);

    // Conecta ao banco de dados
    $conexao = conecta();

    // Prepara a instrução SQL
    $stmt = mysqli_prepare($conexao, $instrucao);

    // Vincula os parâmetros da instrução
    if (isset($tipo)) {
        $comando = 'mysqli_stmt_bind_param($stmt,';
        $comando .= "'" . implode('', $tipo) . "'";
        $comando .= ', $' . implode(', $', array_keys($dados));
        $comando .= ', $' . implode(', $', $campos_criterio);
        $comando .= ');';

        eval($comando); // Executa o comando
    }

    // Executa a instrução
    mysqli_stmt_execute($stmt);

    // Verifica se a execução afetou alguma linha
    $retorno = (boolean) mysqli_stmt_affected_rows($stmt);

    // Armazena erros, se houver
    $_SESSION['errors'] = mysqli_stmt_error_list($stmt);

    // Fecha a instrução
    mysqli_stmt_close($stmt);

    // Desconecta do banco de dados
    desconecta($conexao);

    return $retorno; // Retorna o resultado da operação
}

// Função para deletar dados de uma tabela
function deleta(string $entidade, array $criterio = []) : bool
{
    $retorno = false; // Inicializa a variável de retorno como falso

    $coringa_criterio = []; // Inicializa o array para os critérios

    // Prepara os critérios para a deleção
    foreach ($criterio as $expressao) {
        $dado = $expressao[count($expressao) - 1];

        $tipo[] = gettype($dado)[0]; // Obtém o tipo do dado
        $expressao[count($expressao) - 1] = '?'; // Substitui o valor pelo coringa
        $coringa_criterio[] = $expressao; // Armazena a expressão de critério

        $nome_campo = (count($expressao) < 4) ? $expressao[0] : $expressao[1];

        $campos_criterio[] = $nome_campo; // Armazena o nome do campo

        $$nome_campo = $dado; // Cria uma variável variável
    }

    // Monta a instrução SQL de deleção
    $instrucao = delete($entidade, $coringa_criterio);

    // Conecta ao banco de dados
    $conexao = conecta();

    // Prepara a instrução SQL
    $stmt = mysqli_prepare($conexao, $instrucao);

    // Vincula os parâmetros da instrução
    if (isset($tipo)) {
        $comando = 'mysqli_stmt_bind_param($stmt,';
        $comando .= "'" . implode('', $tipo) . "'";
        $comando .= ', $' . implode(', $', $campos_criterio);
        $comando .= ');';

        eval($comando); // Executa o comando
    }

    // Executa a instrução
    mysqli_stmt_execute($stmt);

    // Verifica se a execução afetou alguma linha
    $retorno = (boolean) mysqli_stmt_affected_rows($stmt);

    // Armazena erros, se houver
    $_SESSION['errors'] = mysqli_stmt_error_list($stmt);

    // Fecha a instrução
    mysqli_stmt_close($stmt);

    // Desconecta do banco de dados
    desconecta($conexao);

    return $retorno; // Retorna o resultado da operação
}

// Função para buscar dados em uma tabela
function buscar(string $entidade, array $campos = ['*'], array $criterio = [], string $ordem = null) : array
{
    $retorno = false; // Inicializa a variável de retorno como falso
    $coringa_criterio = []; // Inicializa o array para os critérios

    // Prepara os critérios para a busca
    foreach ($criterio as $expressao) {
        $dado = $expressao[count($expressao) - 1];

        $tipo[] = gettype($dado)[0]; // Obtém o tipo do dado
        $expressao[count($expressao) - 1] = '?'; // Substitui o valor pelo coringa
        $coringa_criterio[] = $expressao; // Armazena a expressão de critério

        $nome_campo = (count($expressao) < 4) ? $expressao[0] : $expressao[1];
        
        if (isset($$nome_campo)) {
            $nome_campo = $nome_campo . '_' . rand(); // Cria um nome de campo único
        }

        $campos_criterio[] = $nome_campo; // Armazena o nome do campo

        $$nome_campo = $dado; // Cria uma variável variável para o critério
    }

    // Monta a instrução SQL de seleção
    $instrucao = select($entidade, $campos, $coringa_criterio, $ordem);
    
    // Conecta ao banco de dados
    $conexao = conecta();

    // Prepara a instrução SQL
    $stmt = mysqli_prepare($conexao, $instrucao);

    // Vincula os parâmetros da instrução
    if (isset($tipo)) {
        $comando = 'mysqli_stmt_bind_param($stmt,';
        $comando .= "'" . implode('', $tipo) . "'";
        $comando .= ', $' . implode(', $', $campos_criterio);
        $comando .= ');';
    
        eval($comando); // Executa o comando
    }

    // Executa a instrução
    mysqli_stmt_execute($stmt);

    // Verifica se a execução retornou resultados
    if ($result = mysqli_stmt_get_result($stmt)) {
        $retorno = mysqli_fetch_all($result, MYSQLI_ASSOC); // Recupera todos os resultados como um array associativo

        mysqli_free_result($result); // Libera o resultado
    }

    // Armazena erros, se houver
    $_SESSION['errors'] = mysqli_stmt_error_list($stmt);

    // Fecha a instrução
    mysqli_stmt_close($stmt);

    // Desconecta do banco de dados
    desconecta($conexao);

    return $retorno; // Retorna os resultados da busca
}

?>
