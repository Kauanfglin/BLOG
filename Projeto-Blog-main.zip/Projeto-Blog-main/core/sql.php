<?php

// Função para inserir dados em uma tabela
function insert (string $entidade, array $dados) : string 
{
    $instrucao = "INSERT INTO {$entidade}"; // Inicia a instrução SQL de inserção.

    $campos = implode(', ', array_keys($dados)); // Cria uma lista de campos (colunas) a partir das chaves do array $dados.
    $valores = implode(', ', array_values($dados)); // Cria uma lista de valores a partir dos valores do array $dados.

    $instrucao .= " ({$campos})"; // Adiciona os campos à instrução.
    $instrucao .= " VALUES ({$valores})"; // Adiciona os valores à instrução.

    return $instrucao; // Retorna a instrução SQL completa.
}

// Função para atualizar dados em uma tabela
function update (string $entidade, array $dados, array $criterio = []) : string
{
    $instrucao = "UPDATE {$entidade}"; // Inicia a instrução SQL de atualização.

    foreach ($dados as $campo => $dado) { // Loop pelos dados a serem atualizados.
        $set[] = "{$campo} = {$dado}"; // Cria uma lista de campos a serem atualizados.
    }
    
    $instrucao .= ' SET '. implode(',', $set); // Adiciona a cláusula SET à instrução.

    if(!empty($criterio)) { // Se critérios de busca foram fornecidos.
        $instrucao .= ' WHERE '; // Adiciona a cláusula WHERE.
    
        foreach ($criterio as $expressao) {
            $instrucao .= ' '. implode(' ', $expressao); // Adiciona cada expressão de critério.
        }
    }

    return $instrucao; // Retorna a instrução SQL completa.
}

// Função para deletar dados de uma tabela
function delete (string $entidade, array $criterio = []) : string
{
    $instrucao = "DELETE FROM {$entidade}"; // Inicia a instrução SQL de deleção.

    if(!empty($criterio)) { // Se critérios de busca foram fornecidos. 
        $instrucao .= ' WHERE '; // Adiciona a cláusula WHERE.

        foreach ($criterio as $expressao) {
            $instrucao .= ' ' . implode(' ', $expressao); // Adiciona cada expressão de critério.
        }
    }

    return $instrucao; // Retorna a instrução SQL completa.
}

// Função para selecionar dados de uma tabela
function select (string $entidade, array $campos, array $criterio = [], string $ordem = null) : string
{
    $instrucao = "SELECT ". implode(', ', $campos); // Inicia a instrução SQL de seleção.
    $instrucao .= " FROM {$entidade}"; // Adiciona a tabela da qual os dados serão selecionados.

    if(!empty($criterio)){ // Se critérios de busca foram fornecidos.
        $instrucao .= ' WHERE '; // Adiciona a cláusula WHERE.
    
        foreach ($criterio as $expressao) {
            $instrucao .= ' '. implode(' ', $expressao); // Adiciona cada expressão de critério.
        }
    }

    if(!empty($ordem)) { // Se uma cláusula de ordenação foi fornecida.
        $instrucao .= " ORDER BY $ordem "; // Adiciona a cláusula ORDER BY.
    }
    
    return $instrucao; // Retorna a instrução SQL completa.
}
?>
