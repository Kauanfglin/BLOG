<?php
session_start(); // Inicia uma nova sessão ou retoma uma sessão existente.
require_once '../includes/valida_login.php'; // Inclui o arquivo para validar o login do usuário.
require_once '../includes/funcoes.php'; // Inclui funções auxiliares personalizadas.
require_once 'conexao_mysql.php'; // Inclui o arquivo para a conexão com o banco de dados MySQL.
require_once 'sql.php'; // Inclui um arquivo que provavelmente contém consultas SQL.
require_once 'mysql.php'; // Inclui um arquivo que pode conter funções específicas para operações MySQL.

foreach ($_POST as $indice => $dado){ // Loop através dos dados enviados via POST.
    $$indice = limparDados($dado); // Limpa os dados e os atribui a variáveis dinâmicas.
}

foreach ($_GET as $indice => $dado){ // Loop através dos dados enviados via GET.
    $$indice = limparDados($dado); // Limpa os dados e os atribui a variáveis dinâmicas.
}

$id = (int)$id; // Garante que o valor de $id é um inteiro, para evitar injeção de SQL e garantir a segurança.

switch($acao){ // Inicia um bloco switch para determinar a ação a ser tomada.
    case 'insert': // Caso a ação seja 'insert' (inserir um novo post).
        $dados = [ // Cria um array associativo com os dados do post.
            'titulo' => $titulo,
            'texto' => $texto,
            'data_postagem' => "$data_postagem $hora_postagem", // Combina data e hora.
            'usuario_id' => $_SESSION['login']['usuario']['id'] // Armazena o ID do usuário logado.
        ];

        insere( // Chama a função 'insere' para adicionar os dados na tabela 'post'.
            'post',
            $dados
        );
        
    break; // Finaliza o case 'insert'.

    case 'update': // Caso a ação seja 'update' (atualizar um post existente).
        $dados = [ // Cria um array com os dados atualizados.
            'titulo'        => $titulo,
            'texto'         => $texto,
            'data_postagem' => "$data_postagem $hora_postagem", // Combina data e hora.
            'usuario_id'    => $_SESSION['login']['usuario']['id'] // Armazena o ID do usuário logado.
        ];
    
        $criterio = [ // Define o critério para localizar o post a ser atualizado.
            ['id', '=', $id]
        ];
    
        atualiza( // Chama a função 'atualiza' para modificar os dados do post.
            'post',
            $dados,
            $criterio
        );
    
        break; // Finaliza o case 'update'.

    case 'delete': // Caso a ação seja 'delete' (deletar um post).
        $criterio = [ // Define o critério para localizar o post a ser deletado.
            ['id', '=', $id]
        ];
    
        deleta( // Chama a função 'deleta' para remover o post.
            'post',
            $criterio
        );
    
        break; // Finaliza o case 'delete'.
}

// Redireciona para a página inicial após a operação.
header('Location: ../index.php');
?>
