<div class="card">
    <div class="card-body text-center">
        <p>Copyright - <a href="http://www.ifsp.edu.br" target="_blank">IFSP</a></p>
    </div>
</div>