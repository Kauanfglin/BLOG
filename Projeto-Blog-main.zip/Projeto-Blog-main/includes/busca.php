<form class="form-inline my-2 my-lg-0" method="get" action="">
    <input class="form-control mr-sm-2" type="search" name="busca" placeholder="Busca" aria-label="Busca">
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
</form>