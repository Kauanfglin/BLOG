<!-- Função para o rodapé do site -->
<div class="card">
    <div class="card-body text_center">
        <p><center>Copyright - <a href="https://bri.ifsp.edu.br/" target="_blank">IFSP</a></center></p>
        <p><center>Site produzido por - <a href="https://github.com/DanielAlvesMorais" target="_blank">Daniel Alves de Morais</a></center></p>
    </div>
</div>