<div class="card">
    <div class="card-body text_center">
        <p>Copyright - <a href="https://bri.ifsp.edu.br/" target="_blank">IFSP</a></p>
    </div>
</div>